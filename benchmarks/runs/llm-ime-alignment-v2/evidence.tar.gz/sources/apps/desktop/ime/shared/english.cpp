#include "english.h"
#include <rime/candidate.h>
#include <rime/registry.h>
#include <rime/segmentation.h>
#include <rime/translation.h>
#include <rime/translator.h>
#include <string>

namespace {
char lower(char c) { return c>='A' && c<='Z' ? c+('a'-'A') : c; }
char upper(char c) { return c>='a' && c<='z' ? c-('a'-'A') : c; }
std::string folded(std::string text) { for (auto& c:text) c=lower(c); return text; }

std::string casing(std::string text, std::string raw) {
    while (!raw.empty() && (raw.back()=='\'' || raw.back()==' ')) raw.pop_back();
    bool capitals=false, lowercase=false;
    for (char c:raw) { capitals|=c>='A' && c<='Z'; lowercase|=c>='a' && c<='z'; }
    if (!capitals) return text;
    if (!lowercase) { for (auto& c:text) c=upper(c); return text; }
    if (!raw.empty() && raw[0]>='A' && raw[0]<='Z' && raw.substr(1)==folded(raw.substr(1))) {
        if (!text.empty()) text[0]=upper(text[0]);
    } else if (folded(text).compare(0,raw.size(),folded(raw))==0) {
        text.replace(0,raw.size(),raw);
    }
    return text;
}

class EnglishCandidate final : public rime::ShadowCandidate {
 public:
    EnglishCandidate(rime::an<rime::Candidate> source, const std::string& raw)
        : ShadowCandidate(source,"arion_english",casing(source->text(),raw)), raw_(raw) {}
    std::string preedit() const override { return raw_; }
 private:
    std::string raw_;
};

class EnglishTranslation final : public rime::Translation {
 public:
    EnglishTranslation(rime::an<rime::Translation> source, std::string raw, size_t start)
        : source_(std::move(source)), raw_(std::move(raw)), start_(start) {
        set_exhausted(!source_ || source_->exhausted());
    }
    bool Next() override {
        if (exhausted()) return false;
        source_->Next();
        set_exhausted(source_->exhausted());
        return !exhausted();
    }
    rime::an<rime::Candidate> Peek() override {
        if (exhausted()) return nullptr;
        auto candidate=source_->Peek();
        if (!candidate || candidate->start()<start_ || candidate->end()<candidate->start() ||
            candidate->end()-start_>raw_.size()) { set_exhausted(true); return nullptr; }
        return rime::New<EnglishCandidate>(candidate,raw_.substr(candidate->start()-start_,candidate->end()-candidate->start()));
    }
 private:
    rime::an<rime::Translation> source_;
    std::string raw_;
    size_t start_;
};

// Reuse Rime's dictionary lookup, completion and prefix graph. This wrapper
// only folds ASCII lookup and restores the user's case on engine candidates.
class EnglishTranslator final : public rime::Translator {
 public:
    explicit EnglishTranslator(const rime::Ticket& ticket) : Translator(ticket) {
        if (auto* factory=rime::Translator::Require("table_translator")) delegate_.reset(factory->Create(ticket));
    }
    rime::an<rime::Translation> Query(const std::string& input,const rime::Segment& segment) override {
        if (!delegate_) return nullptr;
        auto result=delegate_->Query(folded(input),segment);
        return result ? rime::New<EnglishTranslation>(result,input,segment.start) : nullptr;
    }
 private:
    rime::the<rime::Translator> delegate_;
};
}

extern "C" void arion_english_register(void) {
    rime::Registry::instance().Register("arion_english",new rime::Component<EnglishTranslator>());
}
