import pathlib,re,subprocess,json
rx=re.compile(r'<<<<<<< ours\n(.*?)=======\n(.*?)>>>>>>> theirs\n',re.S)
def stage(n,p):return subprocess.check_output(['git','show',f':{n}:{p}'],text=True)
def resolve(p,fn):
 f=pathlib.Path(p);index=0
 def pick(m):
  nonlocal index
  value=fn(index,m[1],m[2]);index+=1;return value
 f.write_text(rx.sub(pick,f.read_text()))
for p in ['apps/desktop/ime/shared/english.cpp','apps/desktop/ime/shared/english.h','apps/desktop/ime/shared/keyboard-data/README.md']:
 pathlib.Path(p).write_text(stage(2,p))
p='scripts/keyboard-runtime.json';ours=json.loads(stage(2,p));theirs=json.loads(stage(3,p));ours['patches']=theirs['patches'];pathlib.Path(p).write_text(json.dumps(ours,indent=2)+'\n')
p='apps/desktop/ime/macos/keyboard.m';resolve(p,lambda i,a,b:b if i==0 else '    arion_spelling_register();\n'+a)
p='apps/desktop/ime/windows/keyboard_runtime.cpp';resolve(p,lambda i,a,b:b if i==0 else ('        ' if i==1 else '    ')+'arion_spelling_register();\n'+a)
p='apps/desktop/ime/shared/learning_multiprocess_test.cpp'
def learning(i,a,b):
 if i==0:return b
 if i==1:return '        arion_spelling_register();\n'+a
 return a.replace('ContextRanker ranked(records);','const unsigned char eligible[]={1,0,1};ContextRanker ranked(records);').replace('},"previous")','},eligible,"previous")')
resolve(p,learning)
p='apps/desktop/ime/shared/pinyin_native_test.cpp';resolve(p,lambda i,a,b:a+b.replace('#include "english.h"\n','') if i==0 else '        arion_spelling_register();\n'+a)
p='apps/desktop/ime/shared/ranking.cpp';resolve(p,lambda i,a,b:a.replace('length(candidates[i])==full','eligible[i]'))
p='apps/desktop/ime/shared/ranking_test.cpp'
def ranking(i,a,b):
 a=a.replace('order(candidates,u8','order(candidates,eligible,u8').replace('auto bilingualOrder=mixed.order(bilingual,u8','const unsigned char fullBilingual[]={1,1,1,0,0,1,1,1};\n    auto bilingualOrder=mixed.order(bilingual,fullBilingual,u8')
 return a+'\n'+b[b.index('    ContextRanker ambiguous'):]
resolve(p,ranking)
for p in ['scripts/lib/keyboard-data.mjs','scripts/lib/windows-keyboard.mjs','scripts/verify-keyboard-bundle.mjs']:
 resolve(p,lambda i,a,b:a)
for p in ['scripts/build-windows-input-method.mjs','scripts/lib/build-ime-learning.mjs','scripts/test-windows-tsf-keyboard.mjs','scripts/test-windows-pinyin.mjs','scripts/test-windows-keyboard-module.mjs']:
 def combine(i,a,b):
  # PR45 feature sources plus the unchanged PR40 English index/fixtures.
  s=b.replace("'english.cpp'","'english.cpp', 'english_lexicon.cpp'").replace("'english.h'","'english.h', 'english_lexicon.h'").replace("'english'","'english','english_lexicon'")
  if p.endswith('test-windows-pinyin.mjs') and i==0:s=s.replace("'pinyin_native_test.cpp']","'pinyin_native_test.cpp', 'english_admission_cases.h']")
  return s
 resolve(p,combine)
p='scripts/check-shared-keyboard.mjs';resolve(p,lambda i,a,b:a.replace("'test-shared-keyboard-learning'","'test-shared-keyboard-learning', 'test-keyboard-spelling'"))
p='scripts/test-shared-keyboard-learning.mjs';resolve(p,lambda i,a,b:b)
s=pathlib.Path(p).read_text().replace("'emoji.cpp', 'spelling.cpp'","'emoji.cpp', 'english_lexicon.cpp', 'spelling.cpp'");pathlib.Path(p).write_text(s)
p='scripts/test-keyboard-input.mjs';resolve(p,lambda i,a,b:"import { englishAdmissionFixtures } from './lib/english-admission-fixtures.mjs';\n"+b if i==0 else b.replace('nativeReport]','nativeReport, ...englishAdmissionFixtures(root)]'))
p='apps/desktop/ime/macos/tests/typing_test.m';resolve(p,lambda i,a,b:a+b if i<2 else a+'\n'.join(b.splitlines()[1:])+'\n')
p='apps/desktop/ime/shared/keyboard-data/arion_pinyin.schema.yaml';resolve(p,lambda i,a,b:a)
s=pathlib.Path(p).read_text();s=re.sub(r'  translator/max_sentences:.*\n|  translator/max_homophones:.*\n|  translator/sentence_cutoff_threshold:.*\n','',s);s=re.sub(r'  english:\n.*?(?=  speller/alphabet:)', '',s,flags=re.S);pathlib.Path(p).write_text(s)
p='apps/desktop/ime/shared/keyboard-data/arion_english.schema.yaml';subprocess.run(['git','rm','--',p],check=True,stdout=subprocess.DEVNULL)
p='specs/007-ime-ranking.md';ours=stage(2,p);theirs=stage(3,p)
typos=next(l for l in theirs.splitlines() if l.startswith('KBD-09:')).replace('KBD-09:','KBD-10:')
personal=next(l for l in theirs.splitlines() if l.startswith('KBD-11:'))
lines=ours.splitlines();at=next(i for i,l in enumerate(lines) if l.startswith('KBD-09:'));lines[at]+=' English lookup folds ASCII case while output follows explicit title/all-capital/mixed-case input over its consumed span, deduplicating transformed case variants. When whole input has no English match and is not complete normal Pinyin, existing lexicon words may consume a proper prefix; the engine owns remaining-suffix conversion, rollback, cancellation and final commit.';lines[at+1:at+1]=['',typos,'',personal]
at=next(i for i,l in enumerate(lines) if l.startswith('| KBD-A13 |'));typoAcceptance=next(l for l in theirs.splitlines() if l.startswith('| KBD-A13 |')).replace('| KBD-A13 |','| KBD-A14 |');lines[at+1:at+1]=[typoAcceptance,'| KBD-A15 | Explicit English case and both Chinese/English segment orders preserve actual consumed ranges, edited suffix rollback, cancellation and stale ownership; original lowercase English/Chinese pages retain order; English prefixes never enter Chinese learning |'];pathlib.Path(p).write_text('\n'.join(lines)+'\n')
