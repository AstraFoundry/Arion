# Synthesis rubric (0–3 each)

1. Preserves PR40 lexicon bytes and existing lowercase candidate ordering/admission without word exceptions.
2. Supports explicit case and both mixed orders using actual consumed spans/engine commits; editing/cancel/focus remain safe.
3. Integrates PR45 typo/fuzzy/personal vocabulary with latest canonical vocabulary/hotword behavior and encrypted publisher-verified delivery.
4. Keeps one bilingual producer, one shared platform implementation and small APIs; avoids duplicates, speculative caches and hidden fallbacks.
5. Can be verified by unchanged 113-case comparison plus native feature/ownership/encryption regressions on actual target OSes.
