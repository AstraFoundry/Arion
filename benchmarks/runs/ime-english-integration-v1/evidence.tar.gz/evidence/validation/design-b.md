# Candidate B: one producer with demand-driven word-prefix selection

## Problem

PR 40 has the desired complete ESDB/CSpell data and standalone ordering, but creates every English candidate with the whole queried segment range and accepts only lowercase lookup. PR 45 already owns correction, personal projection and source-span plumbing. Its Easy English table translator and default bilingual competition must not replace PR 40. Latest main also stores standalone ASR hotwords and groups aliases by exact canonical spelling; a stale PR 45 vocabulary file would remove that behavior.

## Usage (caller's view)

The runtime still registers one bilingual component. It creates the PR 45 `arion_pinyin` producer internally and offers the same full-word English matches first:

```cpp
arion_spelling_register();
arion_english_register(data, error, sizeof(error));
// Schema uses only arion_bilingual; no easy_en schema, table or translator.
```

- `Query("hello", fullSegment)` retains PR 40's exact/suggestion/lookup order and source forms.
- `Query("hElLo", fullSegment)` uses folded lookup but applies the raw typed case to actual English candidates. Equal transformed display/range pairs occupy one slot.
- `Query("hellonihao", fullSegment)` can expose `hello` consuming `[start,start+5)`. Selection remains provisional; the remaining `nihao` is queried by the same producer and commits `hello你好` once.
- `queueKeyboardVocabulary` projects approved reading-bound canonical records from the existing encrypted store, sends one revisioned authenticated snapshot, and only acknowledges the current projection. ASR hotword eligibility is independent of keyboard reading.

## Shape

Keep the sorted complete lexicon and tournament indexes unchanged. Add a bounded exact-word-prefix view; do not introduce a trie, second dictionary, table compilation or supplementary completion model.

```cpp
class EnglishLexicon {
 public:
  struct WordPrefix {
    size_t bytes;             // Exact consumed raw ASCII prefix; 2..128.
    std::vector<Entry> forms; // Original family/rank, same loaded lexicon.
  };
  Matches Query(std::string_view folded,
                Completion mode = Completion::Suggest) const; // Existing behavior.
  std::vector<WordPrefix> WordPrefixes(std::string_view folded) const {
    throw std::logic_error("not implemented");
  }
 private:
  const Word* ExactWord(std::string_view folded) const {
    throw std::logic_error("not implemented");
  }
};
```

`ExactWord` is the single lower_bound implementation shared by existing exact lookup and word-prefix lookup. `WordPrefixes` checks at most 127 distinct boundaries, from `min(128,input.size()-1)` down to two, returning only existing exact words. This is bounded by the already validated maximum key size, not dictionary population. Longest consumed words lead; existing word rank and source family order break ties. It is not a broad completion scan or a cache to maintain. Returning copied entries is acceptable at this small bounded boundary; returning immutable word handles tied to an owning lexicon is an equally small implementation if preferred.

```cpp
struct EnglishDisplay {
  static std::string Fold(std::string_view raw) {
    throw std::logic_error("not implemented");
  }
  static std::string Apply(std::string source, std::string_view rawPrefix) {
    throw std::logic_error("not implemented");
  }
};
class BilingualTranslation : public rime::Translation {
  // Full-input lanes remain PR40. Optional word-prefix lane owns entries and
  // scalar start/end only, never a Segment/menu/context ownership cycle.
};
```

The display policy is PR 45's lowercase/title/all-caps/explicit mixed-case rule applied to the **consumed prefix only**. Full lowercase input preserves source-native display, e.g. `github` → `GitHub`. Prefix `HELLO` in `HELLOnihao` must use `HELLO`, not the case classification of the whole mixed string. Duplicate transformed `(text,start,end)` values are skipped locally without coalescing distinct producer IDs or discarding Chinese candidates.

### Prefix admission and scheduling

1. Build the original PR 40 Chinese and full-input English proposal.
2. If full-input English `Matches` is nonempty, use the old PR 40 schedule verbatim. This preserves standalone full word/completion ordering and all existing exhaustive lanes.
3. When no full-input English match exists, inspect actual lexicon word prefixes lazily. A wholly normal Pinyin input with a full-input Chinese proposal keeps its existing schedule and does not gain automatic English prefix slots. This protects ordinary Chinese words and sentences.
4. Otherwise place actual full-input Chinese proposals first, then a finite word-prefix lane, then unchanged partial/abbreviated Chinese alternatives. The mixed partial choices are available without claiming automatic whole mixed-sentence correctness. Typo/fuzzy-enabled inputs may contain an invalid Pinyin suffix, so do not require a second independently implemented suffix parser: selecting the real English span lets the production Chinese producer parse/correct the remainder.
5. Use non-Phrase `SimpleCandidate("arion_english", start, start+prefix.bytes, display, "", rawPrefix)` for English. Never insert a display string directly and never wrap a Chinese Phrase with English output.

The new lane has one legitimate producer decision point, not platform-specific heuristics. No per-word exceptions, fixed English preview quota or adjusted corpus thresholds are introduced.

### PR 45 feature reuse

- Instantiate `Translator::Require("arion_pinyin")` inside `BilingualTranslator`, using the existing `translator` ticket namespace. Register spelling and personal support before bilingual session creation. This preserves one Chinese dictionary/learning owner and the `Context* → SpellingTranslator` registry used for vocabulary replacement.
- Reuse `spelling.*`, `personal_vocabulary*`, the correction-identity runtime patch/build provenance, encrypted store/projection, publisher validation, monotonic delivery, platform settings and native tests via the original implementation commits with three-way reconciliation.
- Keep PR 40's standalone Shift raw commit and protected English slots ahead of Emoji. Do not transplant PR 45's deletions of these behaviors.
- Adopt PR 45 `ArionCandidateMetadata` through shared menu, native adapters and ranker. Rank only candidates with compatible actual consumed spans; English/Emoji slots remain fixed. Avoid retaining the obsolete Emoji-only metadata API alongside it.
- Preserve the old default Chinese query configuration. PR 45's global `max_sentences: 5`/homophone settings must not silently change default Chinese pages. If its correction search needs expanded sentence generation, scope that setting to the enabled correction path and restore it, rather than changing the entire normal producer.
- Merge `KeyboardPinyin` additively into latest `MemoryEntry`/encrypted `Entry` and existing conversion helpers. Keep `Hotword`, canonical-only `From == ""` entries, learned origin and grouped alias removal intact. Editing a reading binds an existing stable approved ID plus exact spelling. Deleting the reading does not delete the hotword or aliases. Deleting one alias must not silently erase another independent reading-bearing record.
- Project keyboard terms from the one encrypted store on read; no parallel mutable term database. Native projected snapshots are separately encrypted delivery caches with explicit revision/ownership, not a new source of truth.

## Pinned Rime evidence

The pinned source `.workspace/keyboard-runtime/source/librime-33e78140250125871856cdc5b42ddc6a5fcd3cd4/src/rime/segmentation.cc` implements `Segment::Close()` by shortening the segment to `candidate.end()` and tagging it `partial`. `Segment::Reopen()` restores the original end while retaining selection semantics. `candidate.h` defines `[start,end)` as consumed input, and `SimpleCandidate` already carries independent text/preedit/range. Therefore an extra segmentor or custom editor decoder is unnecessary.

PR 45 `spelling.cpp` constructs `SpellingTranslator` as a `ScriptTranslator`, registers it as `arion_pinyin`, and maintains its personal registry by `engine_->context()`. Personal matches already create non-Phrase candidates with `segment.start + match.end`, so the producer supports partial ranges without platform text rewrites.

## Module map

- `shared/english_lexicon.{h,cpp}`: bounded exact-word-prefix search over existing data.
- `shared/english.cpp`: raw/folded query, display projection, deduplication, single bilingual schedule.
- `shared/keyboard-data/arion_pinyin.schema.yaml`: uppercase admission and one bilingual producer; correction parameters retain off-default semantics.
- PR 45 shared spelling/personal/metadata/ranking modules: native features and range invariants.
- macOS/Windows existing typing adapters: same shared menu metadata and secure session lifecycle.
- Core vocabulary types, encrypted store, bootstrap and IME bridge: additive reading and revisioned delivery; preserve latest hotword/grouped semantics.
- Existing keyboard/vocabulary FSD features and catalogs: opt-in controls/readings, stale/error/pending feedback.

## Tradeoffs accepted

- Accept at most 127 exact binary searches for a genuinely unmatched mixed input to avoid a second index, new dictionary format and default-page churn. Existing standalone inputs do not pay this path.
- Accept that ambiguous wholly valid Pinyin stays Chinese first; no language model is introduced to infer hidden mixed intent.
- Accept explicit partial selection as the feature. The measured default mixed failures are not solved by relabeling them successful.

## Alternatives considered

A new Rime segmentor could split the alphabetic stream into English and Pinyin segments before translation. It exposes intent policy to segmentation, changes which original Chinese hypotheses exist, and complicates rollback/caret ownership; it loses despite a superficially smaller translator.

A second trie or Rime Easy English table could provide common-prefix search. It adds format/index/build/coverage obligations or changes membership/case order. Existing sorted exact keys already supply the bounded query needed, so that larger interface has no justified benefit.

Always interleaving partial English matches into the existing standalone lanes is rejected: `hello`, `artifi`, `xin` and long normal Chinese can all acquire extra short-word candidates and break the retained ordering before any mixed benefit is measured.

## Synthesis decision

Candidate B recommends demand-driven exact prefix lookup and original-lane preservation as the base. The orchestrator will compare it with the other candidate and fill the final synthesis.

## Open questions and risks

No extra user boundary decision is needed: all requested features and persistence paths are authorized. Verify these implementation risks: does a wholly normal Pinyin/Chinese guard retain all baseline pages; does a case-transformed duplicate disappear without losing distinct source spellings; do partial-prefix candidates preserve normal Shift raw commits, punctuation, selected-prefix rollback, Escape/focus invalidation and Chinese-only learning; do explicit correction settings introduce any default Chinese page change?

## Next implementation step

Three-way transplant the PR 45 feature modules while retaining PR 40 English/schema behavior, then implement the exact-word-prefix/display projection seam and test it against the unchanged native 113 inputs before any admission/rank tuning.
