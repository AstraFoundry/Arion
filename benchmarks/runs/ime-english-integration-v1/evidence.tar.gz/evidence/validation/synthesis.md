# Integration architecture

Use candidate B as the base, with candidate A's scalar consumed-span and explicit-case deduplication details. Both candidates converged on existing sorted-lexicon exact-prefix lookup rather than a new Rime segmentor or dictionary. Do not import Easy English or the historical experimental corpus tree.

Caller API remains native key/actual engine index/revision. The bilingual producer keeps PR40 whole-input Query lanes unchanged, creates PR45's arion_pinyin child for typo/fuzzy/personal Chinese candidates, folds only English lookup and transforms output from the consumed raw English span. Proper-prefix queries are bounded by the existing 128-byte key limit, use exact sorted membership and run only when whole-input English has no matches. Normal full-Pinyin inputs retain original Chinese pages. New finite prefix candidates use shorter actual ends so Rime owns suffix conversion and rollback. Case-transformed duplicate text/range pairs are skipped.

Adopt PR45 consumed-range metadata and eligibility across both hosts, retaining PR40 fixed English slots ahead of Emoji and standalone Shift raw commits. Keep normal Chinese sentence/homophone settings; do not introduce PR45's experimental global generation expansion.

Transplant the feature implementation with three-way reconciliation. Add reading fields/actions/projection/secure delivery to current approved memory without removing canonical grouping, standalone ASR hotwords or independent alias deletion. Native projected caches remain encrypted, revisioned and publisher verified. Typo and eleven fuzzy switches default off; personal readings are explicit.

Rubric scores (parent): A = 3/2/3/3/3; B = 3/3/3/3/3. B accommodates typo/fuzzy suffixes without a second pristine-suffix parser; A's stricter suffix gate would unnecessarily exclude those feature combinations. Rejected: second translator/Easy English, a new segmentor, extra trie/cache, per-word exceptions and global sentence expansion. Cross-judge verdict is retained separately.

Verification: unchanged English lexicon digest and admission fixtures; case and bidirectional mixed ownership/edit/cancel regressions; typo operations and independent fuzzy pairs; add/delete/read/revision/publisher/encryption and grouped-hotword UI regressions. Rerun the frozen 113 cases against the exact baseline with alternating measured rounds. Actual Windows checks require Windows; compilation or macOS cannot substitute for them.
