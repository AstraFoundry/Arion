# Native implementation review

Read-only source review; no tests, builds or profiling were run during this pass.

## Actionable finding

### [P2] Exclude normal apostrophe Pinyin from the new English-prefix lane

`apps/desktop/ime/shared/english.cpp:35-41` still constructs `Syllabifier("", false, true)`. The new prefix gate at `english.cpp:142` now relies on this method to decide whether a whole input is normal Pinyin. With no delimiters configured, `ni'hao` and `xi'an` are classified non-normal: pinned `syllabifier.cc` skips leading/trailing delimiters only when they occur in `delimiters_` (lines 57–61 and 95–98).

The whole English query rejects apostrophes, but `english_lexicon.cpp:122-128` accepts the leading letter run and returns its exact dictionary prefixes. The actual staged lexicon contains `ni → Ni` and `xi → xi,Xi`. Consequently the new producer emits Ni/Xi partial candidates after full Chinese candidates for ordinary apostrophe Pinyin, shifting its default page relative to PR40. Previously the empty whole English query returned the Chinese producer directly. This violates the promised preservation of normal lowercase Chinese pages; the unchanged 113-case corpus has no apostrophes, and existing native apostrophe assertions only check that 你好 exists and commits.

Use the actual Pinyin delimiter semantics for the whole-normal exclusion, e.g. the same space/apostrophe delimiters as the production Chinese parser, while leaving raw candidate ranges untouched. Add a baseline page/order regression for at least `ni'hao` and `xi'an`. This is a source-proven path, not a runtime measurement from this review.

## Checked without further actionable findings

- Whole-input English exact/suggestion/lookup lanes remain PR40's policy. The new exact prefix search uses the authoritative sorted keys, bounds candidate prefix length to 128 bytes, and permits longer total mixed input. No new table/index or Easy English dependency is present.
- Case projection uses the consumed raw prefix. Local transformed duplicate skipping is compatible with the current grouped case-family stream; lowercase source forms remain distinct and ordered. SimpleCandidate end uses the actual shorter consumed byte range.
- Shared menu metadata/ranking signatures are migrated through macOS, Windows module exports, function pointers and test source builders. English slots remain fixed during Chinese context reordering, and original English-before-Emoji protection remains in menu.c.
- PR40 standalone Shift raw commit remains in both macOS and Windows paths. Full provisional Escape clearing is present. Existing native session/index/revision selection remains the commit path.
- Both initial Windows startup and reset register spelling before the bilingual producer. Multiprocess workers register the same required producer dependencies.
- Runtime staging preserves PR40 English data/profile validation and includes PR45 correction provenance. Windows private Prism/ScriptTranslator exports and matched SDK declarations are present. Normal schema sentence/homophone expansion from PR45 has not been copied.

## Boundaries

Windows ABI declarations/build inputs look consistent statically; this pass does not establish successful Windows linking, native execution or installed TSF dispatch. The parent-reported 82-case native/core/shared/UI checks were not rerun by this reviewer. Performance, long-input cost and 113-case preservation still require the planned measured replay. Unknown/typo suffixes are intentionally left to the Chinese producer after real prefix selection; they are not an additional correctness finding.
