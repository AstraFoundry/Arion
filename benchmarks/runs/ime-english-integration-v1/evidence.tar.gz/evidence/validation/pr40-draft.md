## Summary

1. Preserve PR 40's complete ESDB70/CSpell English lexicon and candidate admission/ranking. Add explicit case and actual partial English ranges for both mixed-input orders (KBD-09/KBD-A13/KBD-A15, ADR 017).
2. Integrate PR 45's optional typo correction and independent fuzzy-Pinyin settings (KBD-10/KBD-A14), plus explicit personal readings from approved encrypted vocabulary (KBD-11, MEM-08, ADR 029).
3. Preserve standalone Shift raw commits, fixed English ranking slots, Emoji protection, grouped vocabulary and canonical ASR hotwords. Retain the existing Windows context MTA repair and parent-SDK CI handoff (CTX-02/CTX-A04, ADR 013).

## Changes

**Desktop IME**
- `shared/english.cpp` folds lookup and projects casing from the consumed raw span. Exact sorted-lexicon prefix membership supplies real shorter candidate ranges; one bilingual producer keeps the existing whole-word lanes. Normal apostrophe Pinyin retains its original pages. There is no Easy English replacement or global sentence-generation expansion.
- `shared/spelling.*`, `personal_vocabulary*`, native hosts and shared metadata add correction ranges, explicit fuzzy edges, revisioned encrypted vocabulary and Han-only context ranking. All correction switches default off. Build/staging scripts verify the pinned correction source patch and retain PR 40's English data closure.
- `english_lexicon.*` reuses the sorted keys for proper-prefix membership. Existing English data/generator/ranking settings remain unchanged. Native tests cover case, exact-once mixed commits, edit/rollback/cancel, typo/fuzzy/personal combinations and all 98 original admission combinations.

**Vocabulary and settings**
- Core memory/domain projection, encrypted store, bootstrap and Go bridge carry explicit readings without changing ASR eligibility or grouped alias deletion.
- `imebridge/vocabulary_delivery.go` coalesces full snapshots, verifies publisher identity and persisted revisions, retries busy delivery and rejects stale outcomes. A new observer of an acknowledged snapshot receives its result without a redundant publication, including recovery after a rejected edit.
- Native Go settings expose typo/fuzzy toggles, reading validation/stale-state handling and localized pending/failure notices in English and Simplified Chinese.

**Evidence and documentation**
- `benchmarks/corpora/ime-pr-comparison-v1` freezes the same 113 tasks. `benchmarks/reproduction/ime-pr-comparison-v1` retains the shared native driver, external evaluator and archive replay. Original PR 40/45 evidence remains immutable; integration results and failed attempts are separate.
- Update KBD requirements, memory/privacy contracts, ADRs 017/029, architecture, build/operations and shared-data documentation. The source-only Rime fixture pins the exact upstream bytes used by correction-patch tests.

## Screenshots


Actual macOS native candidate-panel captures. Candidate text changes identically across interface locales; no interface-copy/layout change is introduced. The image-only branch `claude/pr-screenshots-english-lexicon` can be deleted after merge. No screenshots are stored on the feature branch.

| **Chinese input `xin`** | **English prefix `artifi`** |
| --- | --- |
| ![xin](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-english-lexicon/pr-screenshots/english-macos-xin.png?raw=true) | ![artifi](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-english-lexicon/pr-screenshots/english-macos-artifi.png?raw=true) |

| **Ambiguous exact word `can`** | **Technical name `github`** |
| --- | --- |
| ![can](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-english-lexicon/pr-screenshots/english-macos-can.png?raw=true) | ![GitHub](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-english-lexicon/pr-screenshots/english-macos-github.png?raw=true) |

| **Chinese input `shi`** | **Abbreviation competition `hel`** |
| --- | --- |
| ![shi](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-english-lexicon/pr-screenshots/english-macos-shi.png?raw=true) | ![hel](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-english-lexicon/pr-screenshots/english-macos-hel.png?raw=true) |

| **Complete `artificial`** | **Technical word `frontend`** |
| --- | --- |
| ![artificial](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-english-lexicon/pr-screenshots/english-macos-artificial.png?raw=true) | ![frontend](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-english-lexicon/pr-screenshots/english-macos-frontend.png?raw=true) |


Native Go test-rendered settings and reading-editor states follow. They use synthetic vocabulary and establish these rendered states, not installed IMK dispatch. The separate image-only branch `claude/pr-screenshots-bilingual-integration` can be deleted after merge. No PNGs are stored on the feature branch.

| **Correction defaults (English)** | **Correction defaults (Simplified Chinese)** |
| --- | --- |
| ![Correction defaults English](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-bilingual-integration/pr-screenshots/keyboard-spelling-en.png?raw=true) | ![Correction defaults Chinese](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-bilingual-integration/pr-screenshots/keyboard-spelling-zh-CN.png?raw=true) |

| **Correction enabled (English)** | **Correction enabled (Simplified Chinese)** |
| --- | --- |
| ![Correction enabled English](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-bilingual-integration/pr-screenshots/keyboard-spelling-selected-en.png?raw=true) | ![Correction enabled Chinese](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-bilingual-integration/pr-screenshots/keyboard-spelling-selected-zh-CN.png?raw=true) |

| **Reading editor (English)** | **Reading editor (Simplified Chinese)** |
| --- | --- |
| ![Reading editor English](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-bilingual-integration/pr-screenshots/vocabulary-reading-en.png?raw=true) | ![Reading editor Chinese](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-bilingual-integration/pr-screenshots/vocabulary-reading-zh-CN.png?raw=true) |

| **Invalid reading (English)** | **Invalid reading (Simplified Chinese)** |
| --- | --- |
| ![Invalid reading English](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-bilingual-integration/pr-screenshots/vocabulary-reading-invalid-en.png?raw=true) | ![Invalid reading Chinese](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-bilingual-integration/pr-screenshots/vocabulary-reading-invalid-zh-CN.png?raw=true) |

| **Stale reading (English)** | **Stale reading (Simplified Chinese)** |
| --- | --- |
| ![Stale reading English](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-bilingual-integration/pr-screenshots/vocabulary-reading-stale-en.png?raw=true) | ![Stale reading Chinese](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-bilingual-integration/pr-screenshots/vocabulary-reading-stale-zh-CN.png?raw=true) |

| **Pending delivery (English)** | **Pending delivery (Simplified Chinese)** |
| --- | --- |
| ![Pending delivery English](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-bilingual-integration/pr-screenshots/vocabulary-keyboard-VocabKeyboardPending-en.png?raw=true) | ![Pending delivery Chinese](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-bilingual-integration/pr-screenshots/vocabulary-keyboard-VocabKeyboardPending-zh-CN.png?raw=true) |

| **Failed delivery (English)** | **Failed delivery (Simplified Chinese)** |
| --- | --- |
| ![Failed delivery English](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-bilingual-integration/pr-screenshots/vocabulary-keyboard-VocabKeyboardFailed-en.png?raw=true) | ![Failed delivery Chinese](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-bilingual-integration/pr-screenshots/vocabulary-keyboard-VocabKeyboardFailed-zh-CN.png?raw=true) |

| **Reading editor (English, dark)** | **Reading editor (Simplified Chinese, dark)** |
| --- | --- |
| ![Reading editor English dark](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-bilingual-integration/pr-screenshots/vocabulary-reading-en-dark.png?raw=true) | ![Reading editor Chinese dark](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-bilingual-integration/pr-screenshots/vocabulary-reading-zh-CN-dark.png?raw=true) |

| **Invalid reading (English, dark)** | **Invalid reading (Simplified Chinese, dark)** |
| --- | --- |
| ![Invalid reading English dark](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-bilingual-integration/pr-screenshots/vocabulary-reading-invalid-en-dark.png?raw=true) | ![Invalid reading Chinese dark](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-bilingual-integration/pr-screenshots/vocabulary-reading-invalid-zh-CN-dark.png?raw=true) |

| **Stale reading (English, dark)** | **Stale reading (Simplified Chinese, dark)** |
| --- | --- |
| ![Stale reading English dark](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-bilingual-integration/pr-screenshots/vocabulary-reading-stale-en-dark.png?raw=true) | ![Stale reading Chinese dark](https://github.com/AstraFoundry/Arion/blob/claude/pr-screenshots-bilingual-integration/pr-screenshots/vocabulary-reading-stale-zh-CN-dark.png?raw=true) |

## Testing

Passed on the integrated macOS sources:
- `pnpm core:check` and `pnpm desktop:check`. The latter includes all 83 real Rime/AppKit cases, 98 English-admission combinations, 4,016 spelling-graph controls, all typo/fuzzy pairs, personal-vocabulary range/deletion and Go/UI checks.
- `node scripts/test-english-lexicon.mjs`; correction-patch/cache and runtime bundle tests; universal input-method build.
- Native Go UI snapshot tests for keyboard settings, reading-editor validation/stale states and pending/failure notices.
- Same-corpus integration comparison and original evidence replay: FINAL_RESULTS_PENDING.
- `pnpm check` and `git diff --check`: FINAL_CHECK_PENDING.

Retained failures include initial transplant compile/assertion failures, a source-stability gate invalidated by concurrent README edits, a signed-run preflight without an available certificate, and the superseded pre-review benchmark. Successful reruns are separate; no failed observation contributes to timing.

**Not run / boundaries**
- `pnpm keyboard:vocabulary:check` cannot reach signed execution here: `security find-identity -v -p codesigning` reports zero valid identities. Re-run with an available Developer ID Application certificate. PR 45's historical signed/installed results do not prove the integrated binary.
- Current Windows native execution and installed TSF acceptance require an ordinary Windows user: `pnpm keyboard:windows:check`. Current-head CI results must be reviewed before merge. Previous-head passes are historical.
- Signed installed application/IMK dispatch, installed restart/offline delivery and visible/GPU typing latency remain separate acceptance gates. The 113 authored tasks do not measure general-user accuracy.
