# Candidate A: one bilingual producer with bounded exact-prefix queries

## Problem

PR40 has the required English source data, rank indexes and admission policy, but every English candidate consumes the entire current segment and its lexicon accepts lowercase keys. PR45 supplies useful case and consumed-range behavior, typo/fuzzy production and approved-personal vocabulary, but its Easy English/table route and some host changes would regress PR40. Integrate PR45's Chinese producer and secure vocabulary chain while retaining PR40 as the sole English producer.

## Usage (caller's view)

The host API remains unchanged: native keys enter one Rime session and native menu selections use revision-scoped actual engine indices. No host assembles a mixed commit.

```cpp
// Existing English standalone query: identical ranked lanes and source spellings.
auto matches = lexicon->Query("artifi", EnglishLexicon::Completion::Suggest);
// Additional operation returns existing words that consume a proper raw prefix.
auto prefixes = lexicon->ExactPrefixes("hellonihao");
// Translator emits SimpleCandidate("arion_english", segment.start,
//     segment.start + prefix.key.size(), cased_display, "", raw_prefix).
```

```go
// Keep the current canonical vocabulary/ASR store and add a reading binding.
entry, err := store.SetKeyboardPinyin(id, expectedSpelling, reading)
// The existing PR45 projection/delivery transports current approved terms.
a.queueKeyboardVocabulary(entries)
```

## Shape

### English data and query

Do not change lexicon format, generation, counts, ranking, frequency thresholds or existing `Query` semantics. Add one exact-prefix operation backed by the already sorted `words_`, with input length bounded by the existing maximum English key length (128). For each proper prefix length 2..min(128,n-1), binary-search equality only. Return source-preferred entries and actual consumed bytes, longest consumed prefix first with stable source/rank ties. Never run the 65-bucket completion lookup once per cut.

```cpp
class EnglishLexicon final {
 public:
  struct Prefix {
    std::vector<Entry> forms; // Existing source case family, copied for ownership.
    size_t consumed;          // ASCII byte count, proper prefix only.
  };
  std::vector<Prefix> ExactPrefixes(std::string_view folded_input) const {
    throw std::logic_error("not implemented");
  }
};
```

The prefix query is pure dictionary membership. It does not decide whether the suffix is Chinese. That decision stays with the bilingual producer, which already owns the Pinyin Prism and Chinese translation.

### One bilingual translator

`BilingualTranslator` creates PR45's registered `arion_pinyin@translator` implementation through `Translator::Require("arion_pinyin")`, replacing its current direct `script_translator` child. Register spelling/personal components before constructing any bilingual sessions. Keep one Rime schema translator `arion_bilingual`; do not add a second English translator or Easy English assets.

`BilingualTranslation` retains PR40's current phases verbatim for ordinary input. Fold only the English query. Chinese producer input remains raw, and the schema explicitly admits uppercase without the inherited uppercase recognizer bypass.

A private case adapter classifies the **consumed English raw span**, not the entire mixed input. It preserves source spelling for lowercase input; applies all caps, title case, or an explicit mixed-case prefix for non-lowercase input. With explicit casing, skip the rest of that same case family's equivalent transformed outputs. Lowercase queries retain every original exact case alternative and their order.

```cpp
enum class CaseIntent { Source, Title, Upper, ExplicitPrefix };
struct EnglishRawSpan { std::string raw; std::string folded; CaseIntent intent; };
std::string DisplayFor(const EnglishLexicon::Entry&, const EnglishRawSpan&);
class EnglishPrefixTranslation final : public rime::Translation {
  // Owns immutable prefix entries and raw bytes, never a Segment/menu reference.
};
```

**Admission boundary:** introduce proper English-prefix choices only when the original whole-input English query has no result and there is no strong complete normal Chinese dictionary word. For each prefix, require a complete normal Pinyin path for the remaining suffix and genuine Chinese producer coverage of that suffix. This preserves every old standalone English/Chinese page. Offer eligible English prefixes ahead of weak generated/abbreviated Chinese, longest consumed span first. When a prefix is selected, Rime itself resumes the suffix and the normal PR40 producer handles it.

The restrictive boundary deliberately avoids treating `ni` + `hao` as a reason to inject Ni into ordinary `nihao`, or treating every short English root as a new standalone-word candidate. It supports the requested English→Chinese conversion for `hellonihao` and `githubnihao` while leaving `artifi`, `hello`, `github`, `can` and normal Pinyin pages intact. If no genuine remaining Chinese path exists, no new English segment is invented.

### Consumed ranges and ranking

Adopt PR45's `ArionCandidateMetadata` throughout the shared menu and native adapter ABI. Eligibility comes from the actual start/end consumed range, not the output's grapheme length. Preserve PR40's English-first-page protection ahead of Emoji rather than copying PR45's removal. English remains non-Phrase and is never admitted to Chinese dictionary learning. An English prefix's `end` is `segment.start + consumed`, not `segment.end`; the raw preedit contains only that span.

### Typo/fuzzy and personal vocabulary

Reuse PR45 `spelling.*`, `spelling_options.h`, Rime correction-identity patch/build provenance, personal vocabulary projection/store and publisher-verified transport. The typo switch and eleven independent fuzzy switches retain explicit off defaults and original candidate retention. Import later Windows Prism-export and translator-worker registration fixes alongside the initial implementation.

Keep one current `vocabulary.Store` record type. Add `KeyboardPinyin` to existing records, preserve hotword flags, alias origins, counters and current canonical grouping. Reading editing should act on a chosen current approved record with its exact expected spelling. Do not restore PR45's older ungrouped vocabulary UI or replace `AddHotword`/batch-alias behavior. Publish the derived current `KeyboardTerms` snapshot after add/remove/repoint/reading changes; stale acknowledgements cannot clear a newer projection's pending/failure state. Keep personal snapshots encrypted and transport publisher checks intact.

## Source evidence

- Pinned Rime `src/rime/segmentation.cc`, `Segment::Close`: selecting a candidate whose `end()` is shorter than the segment splits it at that exact end. No additional native insertion path is required.
- The same file's `Segment::Reopen` restores the original end on rollback; `Context::ReopenPreviousSegment` uses this state for Backspace.
- PR40 `english.cpp::TakeEnglish` currently always emits `start_,end_`; this is the direct reason it cannot offer an English prefix consuming only `hello` from `hellonihao`.
- PR40 lexicon has sorted keys and complete case families in `words_`; exact equality can reuse this authoritative data without another trie/table format.
- PR45 `spelling.cpp::SpellingTranslator` derives from ScriptTranslator, adds typo/fuzzy and a revisioned personal vocabulary for its engine context, and retains real original candidates.
- PR45 `keyboard_vocabulary.go` already owns projection identity and stale delivery outcomes. Its `SetKeyboardPinyin` guards approved ID plus exact spelling. Latest PR40 separately introduced grouped canonical UI and standalone ASR hotwords, so those areas require semantic reconciliation rather than file replacement.

## Module map

- `ime/shared/english*`: unchanged data/ranks plus proper-prefix equality and private case adapter.
- `ime/shared/spelling*`, `personal_vocabulary*`: reused PR45 Chinese/personal producer.
- `ime/shared/menu*`, `ranking*`, `emoji*`: true candidate ranges and eligibility, retaining PR40 slot protection.
- `ime/{macos,windows}`: shared APIs/preferences/transport; preserve current Shift raw-commit behavior and current main host lifecycle.
- `packages/core/domain`, desktop vocabulary store/bootstrap/bridge: additive reading projection on current canonical/ASR model.
- Native keyboard/vocabulary settings and catalogs: reuse existing style and grouped surface; no second form/model.
- Stage/build/verify scripts: keep PR40 English closure and PR45 correction patch/ABI closure together.

## Synthesis decision

Candidate A recommends narrow three-way transplantation of PR45 feature commits into PR40, followed by a small lexicon-driven prefix path inside the one bilingual producer. It does not recommend merging all historical benchmark artifacts or replacing PR40 English implementation.

## Tradeoffs accepted

- We accept at most 127 bounded sorted-key equality checks for a mixed-only query, in exchange for no second dictionary/index format and no effects on the ordinary query path.
- We accept conservative mixed-prefix admission in exchange for preserving PR40's established standalone ordering. Arbitrary adjacent English words or invalid-Pinyin suffixes are outside this operation.
- We accept source-preferred casing plus explicit user-case projection rather than importing Easy English aliases.

## Alternatives considered

A custom English Rime segmentor/table translator could make Rime own all bilingual segmentation, but duplicates PR40 dictionary indexing or requires a second generated closure and exposes competing scores. It loses the existing admission/order guarantee and has a much broader activation/learning surface.

An automatic pre-tokenization pass that rewrites raw input or emits a final mixed string is smaller initially but loses candidate consumed-range identity, rollback and exactly-once ownership. Reject it.

Returning every dictionary prefix on every query would be easy but would introduce short English fragments into normal Pinyin and ordinary completions. Reject it.

## Open questions and risks

No user clarification is required for these implementation choices. Do exact-prefix validation costs remain bounded under long input, and does the conservative gate cover the frozen mixed cases? Prove with native traces and extra long/ambiguous inputs. Does PR45 personal-candidate type bypass PR40's `WholeWord` protection and change personal-vocabulary ordering? Preserve its first-choice protection using typed consumed metadata rather than broadening all candidates to Phrase. Can spelling-source runtime changes preserve normal candidate bytes/order with correction disabled? Compare the unchanged 113 tasks plus the full old admission suite before declaring completion.

## Next implementation step

Apply the source-only PR45 feature changes with three-way conflict resolution, preserving PR40 English files/data, current Shift behavior and grouped vocabulary; then add the bounded exact-prefix/case path and native regression assertions before running the frozen comparison.
