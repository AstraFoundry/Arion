# Integration design cross-judgment

## Decision

Use **B** as the base, with A's explicit scalar-span ownership and consumed-span case projection/deduplication. The designs converge on the same small extension of PR40's sorted lexicon and its single bilingual producer. Neither needs Easy English, a second English producer, a new segmentor, an alternate editor decoder or a new persistent English index.

## Rubric scores

Scores assess the proposed design, not completed implementation evidence.

| Criterion | A | B | Reason |
| --- | ---: | ---: | --- |
| Preserve PR40 data and ordinary ordering | 3 | 3 | Both leave file format, source membership, counts, rank/admission and existing full-input lanes intact. B explicitly protects wholly normal Chinese sentences as well as words. |
| Case, mixed spans and ownership | 2 | 3 | Both use real shorter candidate ends. A additionally requires a pristine normal Pinyin suffix, which excludes precisely the typo/fuzzy suffixes now requested. B lets the authoritative Chinese producer parse the remainder. |
| Typo/fuzzy/personal and current vocabulary | 3 | 3 | Both reuse producer/transport/store modules and require additive integration with grouped aliases and standalone ASR hotwords. |
| One shared implementation and small APIs | 3 | 3 | B's shared exact-key helper prevents a second equality implementation; bounded prefix search needs no speculative trie/cache. |
| Verification of unchanged and extended behavior | 2 | 3 | Both retain the 113 cases and native lifecycle tests. B also calls out the global sentence/homophone configuration hazard that could otherwise invalidate default-page preservation. |
| **Total** | **13** | **15** | |

## Required synthesis details

1. Keep original English `Query` exact/suggestion/lookup scheduling when full-input matches are nonempty. Proper English-word prefix lookup runs only for an unmatched mixed query; exclude wholly normal Pinyin/Chinese input from automatic new prefix slots. Preserve normal word and sentence pages, not just `phrase`-typed heads.
2. Apply the 128-byte dictionary bound to each candidate word prefix, not to the total mixed input. A long mixed input can still begin with a valid short English word. Use one exact-key lower_bound helper; never execute broad completion scans once per cut.
3. Project raw case from the English candidate's consumed bytes. Deduplicate only equal transformed `(text,start,end)` results. Leave lowercase source-form families and their original order intact. Keep only scalar ranges/raw text in translations, avoiding Segment/Menu ownership cycles.
4. The new candidate uses `[segment.start, segment.start + prefix.bytes)`. Existing Rime `Segment::Close/Reopen` owns continuation and rollback. No host writes candidate display text directly.
5. Delegate Chinese to registered PR45 `arion_pinyin`, preserving its per-context personal vocabulary registry. Register spelling before constructing bilingual sessions. Keep `arion_bilingual` as the schema's sole language producer.
6. Retain PR40 normal sentence/homophone configuration. PR45's schema globally sets `max_sentences: 5`, `max_homophones: 3` and cutoff `0.1`; copying those changes the normal producer even with correction off. PR45 `queryPinyin` already uses the direct ScriptTranslator path when typo/fuzzy are off and a scoped correction-search path when on. Transplant capabilities, not unrelated normal-search expansion.
7. Adopt consumed-range metadata/ranking contracts throughout both native adapters and module ABI. Retain PR40's fixed English slots, protection ahead of Emoji and standalone Shift raw commit. PR45 removes those behaviors; copying its entire menu/typing files is unsafe.
8. Add `KeyboardPinyin` and derived snapshots to the current approved encrypted records. Keep current canonical grouping, standalone hotwords, learned origins/counters and alias-specific removal. Preserve PR45 expected-spelling guards, monotonic revisions, publisher validation and stale-ack identity checks.

## Verification obligations

Freeze data generation and verify the resulting lexicon digest remains unchanged. Run existing admission/lexicon tests plus the unchanged 113-input comparison; unchanged ordinary lowercase English/Chinese pages must remain byte/order stable. Add real mixed-prefix range, explicit-case dedup, rollback/edit, Escape, focus/stale callback, raw Shift, punctuation and no-English-learning regressions. Include correction/fuzzy suffixes after an English selection and personal-vocabulary add/delete/restart/tamper/delivery tests. Report actual macOS execution separately from Windows compilation/CI/native/installed acceptance; no OS claim follows from source transplantation alone.

No additional user scope decision is required. The requested feature/persistence boundaries are explicit. The remaining questions are implementation and verification obligations.
