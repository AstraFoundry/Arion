# Bilingual keyboard architecture grounding

## Overview

PR 40 (`7945cffb0c8fd946fe57729bd49cce3c323aaed6`) already owns the desired English dictionary and cross-language display ordering. PR 45 (`264b882fc1f83adfc29285d3e80324f308734671`) adds useful input ownership, spelling and vocabulary capabilities, but its independent Easy English table producer is not a replacement for that policy. The integration should keep one bilingual producer and retain the original Rime session as the authority for partial selections and commits.

The user's expanded scope also includes PR 45 typo correction, eleven fuzzy pairs, personal-vocabulary settings and authenticated delivery. These features extend the Chinese producer and composition/application adapters; they do not require importing Easy English or changing the English lexicon.

## Key concepts

- `EnglishLexicon::Matches` exposes disjoint exact, admitted suggestion and deferred lookup cursors. Grouped TSV v2 preserves original display forms, observed counts and word ranks. Its `Query` currently accepts lowercase ASCII only.
- `BilingualTranslation` consumes one original Chinese translation and those English cursors. Normal full-Pinyin plus a full-range dictionary Chinese phrase protects the Chinese head. Exact/suggestion/lookup ordering is explicit and must remain the baseline for unchanged lowercase whole-input queries.
- Rime `Candidate::start/end` are consumed raw-input byte offsets, not display-text length. A shorter `end` is the engine's existing partial-conversion mechanism.
- `ArionPinyinMenu` maps displayed slots to actual engine indices. Native hosts select those indices and apply actual Rime commits; they must never insert candidate display text as a substitute.
- PR 45 `SpellingTranslator` wraps the original script translator and integrates personal projection into actual Chinese candidates. `SpellingCorrector` reads per-session `arion_typo` and independent fuzzy options. `PersonalVocabulary` is an immutable explicit-reading projection, separate from ordinary encrypted keyboard learning.

## How it works

A native key reaches macOS `ArionTyping::handleEvent` or Windows `Typing::apply`. Shared `input.c` decides pass-through, mode switching and key normalization. Rime's schema runs `abc_segmentor`, which consumes only the configured `speller/alphabet`; PR 40 only includes lowercase and inherited uppercase recognition diverts uppercase input. PR 45 extends this alphabet to both cases and clears the inherited uppercase recognizer pattern.

Rime `ConcreteEngine::Compose` truncates the active input at the raw caret, calculates segments and calls each translator with that segment's input substring. PR 40's `arion_bilingual` calls the original script translator, checks normal spelling through the packaged Prism, queries its English lexicon, and yields the combined stream. Every generated English `SimpleCandidate` currently claims the entire segment, so English cannot be selected as the first part of `hellonihao` or `githubnihao`.

Rime `Segment::Close` already shortens a selected segment to `candidate.end()` and marks it partial. The next composition query starts at the remaining raw suffix. Producing an English candidate with the real shorter consumed span therefore permits English→Chinese selection without a new host splitting algorithm. Chinese→English already works in PR 40 for lowercase suffixes because script candidates can consume a shorter prefix. No copied `Segment` or retained `Menu` should be introduced: it risks translation/menu ownership cycles, and scalar input bounds suffice.

PR 45 folds only English lookup, then reconstructs display casing from the consumed raw spelling: lowercase input preserves native dictionary case, all caps uppercases the result, title case uppercases the first letter, and explicit mixed-case prefixes overwrite matching source prefixes. Its wrapper also preserves raw preedit and original consumed ranges. The same policy can be applied to PR 40 lexicon candidates without a table translator. Multiple native case forms may collapse to one transformed output under all-caps/mixed-case input; avoid duplicate visible spellings while retaining genuine distinct source forms for unmodified lowercase queries.

After a producer change, the menu still loads real candidates by engine index and optionally reorders Chinese slots through encrypted personal context. PR 40 protects English slots and has output-length-based ranking eligibility. PR 45 exports every candidate's type/start/end and derives eligibility from matching consumed spans. Integrating that range protection is relevant to partial input, but PR 45's ranker/menu implementation also removes PR 40's English fixed-slot preservation and protection ahead of Emoji; those removals must not be copied wholesale.

On selection, the engine may retain a selected first segment while the second remains marked. Backspace initially reopens the selected segment rather than immediately deleting a character. Escape, cancellation, ownership loss and stale revision callbacks must clear or reject the entire still-provisional composition. PR 45's shared `pinyin.c` explicitly clears the full Rime composition after handled plain Escape because upstream Escape can clear only its unfinished suffix.

For the expanded spelling/personal-vocabulary scope, PR 45 registers `arion_spelling_register()` after Rime initialization and before sessions. The bilingual producer's Chinese delegate must then use the registered `arion_pinyin` component, not bypass it by directly requiring `script_translator`. The custom spelling translator itself owns the underlying original and corrected script producers, ordinary Chinese identity and personal candidate projection. Keep the single schema translator `arion_bilingual`; importing PR 45's separate `arion_english@english` schema would reintroduce competing English scheduling and Easy English assets.

The application owns approved vocabulary and explicit readings. `domain.KeyboardTerms` validates the projection; encrypted store and bootstrap queue the latest complete snapshot. `imebridge` owns verified connection/capability/activation admission and one replaceable desired-snapshot delivery worker. Native per-session publication/restoration persists a revisioned encrypted projection before exposing it, rejects busy/stale updates, and never mutates ordinary learned phrases. UI pending/failure state belongs to the identity of the currently requested projection, so an old acknowledgement cannot clear a newer edit.

## Where things live

### Core bilingual/case/range integration

- `apps/desktop/ime/shared/english.cpp`: preserve PR 40 mixing, add raw-case transformation and real consumed-prefix English candidates, compose the Chinese delegate with PR 45 spelling/personal support.
- `english_lexicon.{h,cpp}`: retain file format/data/ranks/admission. A bounded dictionary-prefix access primitive may be appropriate, but prefix lookup must not replay/drain broad completion streams or encode corpus words.
- `shared/keyboard-data/arion_pinyin.schema.yaml`: add uppercase alphabet/recognizer changes while retaining `arion_bilingual`; retain English-data format and build verification.
- `shared/pinyin.c`: full provisional Escape cancellation; preserve PR 40 `arion_pinyin_commit_raw`.
- `shared/emoji.{h,cpp}`, `shared/menu.{h,c}`, `shared/ranking*`: consumed-span metadata/eligibility if needed; retain English-slot preservation, Emoji insertion protection and no-English-learning policy. Migrate every signature caller together.
- `macos/{typing,ranking,keyboard}.*`, Windows `{typing,keyboard_runtime,keyboard_client}.*`: use the shared candidate contracts and preserve native session/revision ownership. Windows module function-pointer signatures must match exported definitions; do not change only one side.

### Expanded PR 45 capabilities

- `shared/spelling.{h,cpp}`, `spelling_options.h`, `personal_vocabulary*`: typo/fuzzy producer, explicit reading/graph matching, encrypted native projection.
- `scripts/lib/keyboard-correction-patch.mjs`, `keyboard-macos-runtime.mjs`, staging/build helpers and `scripts/keyboard-runtime.json`: actual corrected raw-length identity and native symbol exports. PR 45 source-built Rime must be staged with its exact patch; existing prebuilt PR 40 library is insufficient for the complete correction feature.
- Core `domain/keyboard_vocabulary.go` and `memory.go`; desktop `infrastructure/vocabulary/keyboard.go`, bootstrap `keyboard_vocabulary.go` and action/load wiring: one approved projection and explicit reading ownership.
- `infrastructure/imebridge/{vocabulary,vocabulary_delivery,peer_darwin}.*`, native host dispatch and Windows strict wire parser: authenticated complete-snapshot publication, deletion, restart-safe revision negotiation and lifecycle invalidation.
- UI `features/{keyboard,vocabulary}`, runtime projection and bilingual copy catalogs: opt-in typo toggle, eleven independent fuzzy pairs, reading edits and delivery feedback.
- ADR 029, specs 003/005/007, existing architecture and test runbooks: retain scope and actual evidence limits.

## Gotchas and constraints

1. Do not transplant PR 45 `english.cpp`, Easy English schema/data, or `initial_quality` competition. They are exactly the weaker English behavior the user asked to replace.
2. Do not remove PR 40 standalone Shift raw-commit behavior. PR 45's older typing implementation discards instead; PR 40 native tests explicitly assert raw commit before switching. Keep `arion_pinyin_commit_raw` and Windows `ShiftASCII` semantics.
3. Do not copy PR 45's removal of English-slot protection in `menu.c` or its ranker sorting all text positions. Preserve English slots and Chinese-only learning while adding consumed-span eligibility.
4. Do not equate display length and raw consumption. New English prefix candidates must point to actual raw bounds; edits, middle-caret queries, nonzero suffix start offsets and a reopened selection must use the current revision's range.
5. Keep lowercase whole-input candidate order stable. Prefix candidates should not indiscriminately add short English words into existing valid full-English/full-Pinyin queries. This needs a structural policy and independent regressions, not fixture exceptions.
6. The frozen comparison has 113 authored inputs. PR 40 succeeds on 4/12 exact-case mixed tasks, PR 45 on 10/12; PR 45 still misses separately selectable `github` in `githubnihao`, even ignoring case. Neither gets any of the twelve intended mixed strings by always choosing the first candidate. Success means explicit partial selection, not automatic mixed-sentence conversion.
7. The core vocabulary/UI/store paths inspected have no commits or diffs between PR 45 base `2c15ee5c` and PR 40 head `7945cffb` (checked those exact refs). That reduces conflicts for the new projection work. It does not prove a freshly fetched newer `main` has no additional changes; check the actual merge base before applying whole files.
8. Broad copying from PR 45 would also change unrelated older settings, raw-Shift behavior and English package closure. A real merge/cherry-pick of its implementation commit is safer than replacing entire files, followed by deliberate conflict resolution around the single bilingual producer.
9. Both native packages must compile the same shared producer and correct private Rime ABI. macOS native/AppKit execution does not prove Windows execution, installed IMK/TSF dispatch or GPU-visible latency. Performance comparison should rerun the frozen inputs with unchanged evaluator targets and retain failed attempts.

## Verification entry points

Keep original lexicon generation, index-malformation/dense-prefix/independent-cursor tests and the existing 98 admission input/page checks. Add native case/mixed ownership assertions from PR 45 without changing expected baseline lowercase ordering: Shift uppercase, all-caps and mixed case, both segment orders, selected-prefix rollback, suffix edits, Escape/mode/focus loss and stale callbacks. Add equivalent native Windows engine/module checks. For expanded scope, include PR 45 independent fuzzy-pair and four-typo-operation tests, ordinary-learning isolation, secure vocabulary publication/deletion/restart and projection-delivery supersession tests.

Use the existing reference-isolated comparison driver unchanged where possible, include all 113 frozen inputs, and compare integrated PR 40 with the frozen original PR 40; retain separate group metrics and only compare timing on shared successful operations. Require original English lexicon/data hashes to remain unchanged. Profile outside reported measurements and do not credit unsupported uppercase passthrough or missing targets as speed gains.
