# Implementation review: vocabulary, store, bootstrap and secure transport

Scope: read-only source inspection of the integrated working tree. No builds, tests, profiling, runtime sign-in, key access or source edits were performed. This review does not independently repeat the passing tests reported by the parent.

## Actionable finding

### P2: returning to an already delivered snapshot can leave the UI pending forever

Evidence:

- `apps/desktop/bootstrap/keyboard_vocabulary.go:29-33` clears `a.keyboardVocabulary` on projection validation/budget failure.
- On a later valid load, `:39-52` allocates a new projection, displays Pending, and installs a callback tied to that new identity.
- `apps/desktop/infrastructure/imebridge/vocabulary_delivery.go:45-48` replaces `d.report`, then returns immediately when the canonical terms equal the existing desired snapshot.
- The worker's `:74-82` waits indefinitely when that desired snapshot was already delivered to the current admission/activation; it does not replay the known result to the new callback.

Concrete sequence: deliver valid snapshot A successfully; create an invalid/over-budget keyboard projection B; then remove the offending entry so the approved projection is exactly A again. Bootstrap creates a new Pending identity, but the bridge already has desired=delivered=A, so no write or callback follows. The native cache is correct, but the new UI pending notice cannot clear until a connection/activation change happens to force another delivery.

This is reachable through normal store operations: `Store.AddHotword`/`AddVariants` retain user-approved entries without a hard 2,000-entry rejection, `SetKeyboardPinyin` validates one reading without checking the projected total, and `domain.KeyboardTerms` rejects an explicitly bound projection once it exceeds 2,000 (`packages/core/domain/keyboard_vocabulary.go:37-38`). Deleting the extra bound entry restores the previous exact A. A transport-frame rejection before `d.desired` changes can produce the same return-to-A problem even when domain validation succeeds.

Suggested repair: retain a durable delivery outcome for the desired snapshot and notify a newly installed observer of that outcome, or keep the bootstrap projection lifecycle consistent with the bridge's deduplication. Preserve content deduplication and avoid unnecessary native writes. Add a focused A → rejected B → A regression asserting that the current notice resolves; existing tests cover unchanged reloads and changed snapshots, but not this recovery path.

This is a static, deterministic control-flow finding. No new execution was requested or performed.

## Checks with no additional concrete regression found

- `Entry.memory` and `entryOf` carry `KeyboardPinyin` through encrypted memory updates; replacing a learned target explicitly clears the now-stale reading, while reinforcing/recalling retains it. The stale editor guard compares both record identity and exact current spelling before writing.
- Grouped vocabulary remains a presentation of independent entry IDs. Canonical-only hotwords stay separate from aliases, and the reading editor binds to the exact selected hotword/variant identity. Removing one alias does not delete an independent hotword or another reading.
- ASR eligibility remains derived from existing Hotword/origin rules. Keyboard projection uses only approved entries with explicit readings and excludes correction aliases/counts from keyboard frequency. Empty reading removes the binding; it does not remove the canonical term or change ASR eligibility.
- `loadVocabulary` does not queue an empty deletion on missing/unreadable app storage. It updates ASR/correction state and queues keyboard terms only after a successful decrypted snapshot load. This preserves the documented offline cache behavior.
- Normal changed-snapshot supersession is identity-bound: both the bridge desired snapshot and bootstrap projection reject outcomes from an older edit. The worker is singular and coalesces content, cancels superseded attempts and waits through voice/update ownership.
- Native publication remains complete-snapshot and revision negotiated: query persisted revision, publish revision+1, validate exact acknowledgement, requery after uncertain writes, reject busy/stale data, and persist before exposing the new projection. Native private projection storage remains separate from ordinary learned phrases.
- macOS publisher admission derives the Developer ID team from the running trusted binary, uses the socket audit token to locate the actual peer, pins the expected code identifier/team requirement, and checks the retained dynamic code on later messages. Capability strings and hello data do not choose trust. Ad-hoc binaries do not gain private vocabulary publication authority.
- Go publication bounds UTF-8 identities/text/readings, rejects duplicate IDs and extra-budget frames, and keeps terms out of logs. Native parsing independently validates positive integer identities, bounded UTF-8 string fields, explicit arrays and dictionary-resolvable readings.

## Verification limits

- Positive Developer ID mutual-publication execution was not rerun in this review. The parent reports that `security find-identity` currently yields zero valid signing identities. Previously archived PR45 signed observations cannot establish current integrated-binary success.
- The parent reports passing current Go bridge/store/UI and native store tests. I inspected relevant source assertions but did not execute them or claim independent test results.
- Actual installed signed app/IMK publication, restart/deletion acceptance, clean consent behavior and installed Windows TSF dispatch remain runtime gates. A successful headless/native fixture alone does not satisfy them.
- No performance or input-quality conclusion follows from this source review; the frozen native comparison is owned by the parent.
