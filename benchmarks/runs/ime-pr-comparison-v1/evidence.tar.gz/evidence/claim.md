# Intended claims and measurement boundary

Compare PR 40 and PR 45 as shipped at frozen heads on the same authored inputs: native first-page candidate rank/recall, quiet Chinese controls, exact case-sensitive mixed partial-selection commits, and native key-to-AppKit-state latency. Report each workload separately; no population accuracy or installed IMK/GPU rendering claim.

Both variants retain their production dictionary and Rime configuration. Typo/fuzzy stay at the default off values. Empty encrypted synthetic profiles, no Keychain, personal vocabulary, cloud or learned ranker history. Fixed page size nine, with a separate five-slot ranking subset. Shared original source driver, compiler/toolchain/optimization, warmups and action policy. References remain in the external evaluator; the driver sees raw keys and actual page-relative selection indices only.

At least five alternating repetitions per side; per-round medians/ranges. Key timing includes production ArionTyping/engine/menu refresh and an actual NSTextView marked-text update. Candidate searching, JSON, controller IPC and pacing sleeps are excluded. Selection-to-AppKit commit and full process/startup costs are recorded separately. Paced subset uses 80 ms gaps outside timed intervals. Background desktop load is observed, not stopped.

No winner for failed/unsupported work based on speed. Restrict comparable speed to cases successful on both variants. Profile outside the timed experiment and retain it; no speedup claim without a measured limiter. Synthetic authored corpus is development/regression evidence and not independently reviewed holdout.
